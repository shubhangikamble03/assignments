package com.yash.oopsassignment;

public class Fruit {
	String fruitName;
	String  fruitColor;
	public Fruit(String fruitName, String fruitColor) {
		super();
		this.fruitName = fruitName;
		this.fruitColor = fruitColor;
	}
	
}
