package com.yash.oopsassignment;

public interface Shape {
	   void area(int a,int b);
}
