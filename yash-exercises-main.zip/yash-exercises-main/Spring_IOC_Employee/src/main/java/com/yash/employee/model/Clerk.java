package com.yash.employee.model;

public class Clerk  implements Employee {

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Object of Clerk class");	
	}
}
