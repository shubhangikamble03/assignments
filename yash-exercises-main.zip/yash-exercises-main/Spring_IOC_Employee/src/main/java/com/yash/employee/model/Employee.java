package com.yash.employee.model;

public interface Employee {
	    void print();
	
}
