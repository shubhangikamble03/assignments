package com.yash.employee.model;

public class Manger  implements Employee {

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Object of Manager class ");
	}	
}
