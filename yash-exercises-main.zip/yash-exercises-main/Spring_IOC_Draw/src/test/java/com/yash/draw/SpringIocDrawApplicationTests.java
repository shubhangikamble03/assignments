package com.yash.draw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIocDrawApplicationTests {

	@Test
	void contextLoads() {
	}

}
