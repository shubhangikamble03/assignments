package com.yash.draw.model;

public abstract class Shape
{
public abstract void draw(double x,double y);
}
